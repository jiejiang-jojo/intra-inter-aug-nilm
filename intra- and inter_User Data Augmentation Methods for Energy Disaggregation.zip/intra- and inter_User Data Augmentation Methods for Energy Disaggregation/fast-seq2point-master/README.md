Energy disaggregation (Pytorch implementation)
